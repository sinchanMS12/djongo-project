from django.contrib import admin

# Register your models 

from CSE.models import Student, Class1, Student1

admin.site.register(Student)

admin.site.register(Class1)
admin.site.register(Student1)